import React from 'react'

function ViewUsers2() {
  return (
    <div>ViewUsers2</div>
  )
}

export default ViewUsers2