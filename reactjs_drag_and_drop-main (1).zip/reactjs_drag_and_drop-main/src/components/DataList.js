const DataList = [
    {
        id:1,
        text:"Reactjs"
    },
    {
        id:2,
        text:"Python Django"
    },
    {
        id:3,
        text:"Ruby Rails"
    },
    {
        id:4,
        text:"HTML"
    },
    
    
]

export default DataList;