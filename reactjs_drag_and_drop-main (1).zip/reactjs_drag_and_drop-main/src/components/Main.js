import React, { useState } from 'react';
import { CardComponent } from './CardComponent';

export const Main = () => {
  return (
   <>
   <div className='header'><h1>Drag and Drop Funcationality..</h1></div>
   <CardComponent />
   </>
  )
}
