import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import Add from './Components/Add'
// import Example from './ex';
import App from './App';



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <Add /> */}
    {/* <Example/> */}
    <App/>
  </React.StrictMode>
);


