import './App.css';
import Pokemons from './components/pokemons';

const App = () => {
  return (
   <>
   <Pokemons />
   </>
  );
}

export default App;
