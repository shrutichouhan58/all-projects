import React from 'react'
import PokemonList from './PokemonList'

const index = () => {
  return (
    <>
    <PokemonList />
    </>
  )
}

export default index;