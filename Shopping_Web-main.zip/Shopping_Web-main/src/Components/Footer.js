import './Footer.css'
import React from "react";
import './Footer.css'

const Footer = () => {
    return (
        <>
            <footer className="footer">
                <div>
                    <h2 className="contact">Contact Us</h2>
                    <p className="para"><h6>Name:shruti chouhan</h6>
                        <h6>Mob:7987162371</h6>
                        <h6>Location:Ujjain</h6></p>
                        <a  href="https://github.com/ShrutiChouhan123/Shopping_Web"  style={{marginLeft:"55rem",color:"white"}}
                ><i class="fa fa-github" style={{fontSize:"35px"}}></i>
                </a>
                </div>
               
                <p className="para2"><p className="para3">shruti@bestpeers.in</p></p>
               
               
                
            </footer>
        </>
    )
}

export default Footer;