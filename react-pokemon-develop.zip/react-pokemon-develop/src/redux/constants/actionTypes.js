export const GET_POKEMONS = 'GET_POKEMONS';
export const GET_POKEMON = 'GET_POKEMON';
export const CHANGE_FILTER = 'CHANGE_FILTER';
