import Todos from './components/todos'

const App =()=> {
  return (
    <Todos/>
  );
}

export default App;
