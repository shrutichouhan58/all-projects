import React from 'react'
import Crud from './components/Crud'

const  App = () => {
  return (
    <Crud/>
  )
}

export default App;

