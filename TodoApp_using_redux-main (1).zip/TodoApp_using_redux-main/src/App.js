import './App.css';
import TodoList from './Component';

function App() {
  return (
    <div>
      <TodoList />
    </div>
  );
}

export default App;
