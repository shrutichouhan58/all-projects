import React from 'react'

function Commnets() {
  return (
    <div>Commnets</div>
  )
}

export default Commnets