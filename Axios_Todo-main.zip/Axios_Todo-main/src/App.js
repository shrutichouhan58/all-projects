import React from 'react'
import Crud from './components/Crud'

function App() {
  return (
    <Crud/>
  )
}

export default App