import '../App.css';
import { useEffect, useState } from 'react';
import axios from 'axios';

function Crud() {
    const [username, setusername] = useState('')
    const [firstname, setfirstname] = useState('')
    const [lastname, setlastname] = useState('')
    const [email, setemail] = useState('')
    const [password, setpassword] = useState('')
    const [data, setstudentdata] = useState([])
    let baseUrl = 'http://127.0.0.1:5500/users/'
    useEffect(() => {
        async function getAllStudents() {
            try {
                const student_data = await axios.get('http://127.0.0.1:5500/users/')
                console.log(student_data.data)
                setstudentdata(student_data.data)
            }
            catch (err) {
                console.log(err)
            }
        }
        getAllStudents()
    }, [])

    let AddData_Post = () => {
        axios.post(baseUrl, {
            username: username,
            first_name: firstname,
            last_name: lastname,
            email: email,
            password: password
        }).then((res) => setstudentdata(res.data))
    }

    const getData = () => {
        axios.get(`http://127.0.0.1:5500/users/`)
            .then((getData) => {
                alert('data deleted')
                setstudentdata(getData.data);
            })
    }


    const Delete = (id) => {
        console.log(id)
        axios.delete(`http://127.0.0.1:5500/users/${id}`)
            .then(() => {
                getData();
            }).catch((err) => console.log(err))
    }



    function update(id) {
        let data1 = prompt("enter username");
        let data2 = prompt("enter fisrtname")
        let data3 = prompt("enter lastname")
        let data4 = prompt("enter email")
        let data5 = prompt("enter password")
        axios.put(`http://127.0.0.1:5500/users/${id}`, {
            username: data1,
            first_name: data2,
            last_name: data3,
            email: data4,
            password: data5
        })
            .then(response => {
                setstudentdata(response.data);
                console.log(response.data)
            })
            .catch((err) => {
                console.log(err)
            })

    }
    return (
        <>
            <div class='main'>
                <div class="center">
                    <h1>Crud With axios</h1>
                    <div class="inputbox">
                        Username <input type='text' value={username} onChange={(e) => setusername(e.target.value)} /><br />
                        <span>Username</span>
                    </div>
                    <div class="inputbox">
                        Firstname<input type='text' value={firstname} onChange={(e) => setfirstname(e.target.value)} /><br />
                        <span>Firstname</span>
                    </div>
                    <div class="inputbox">
                        Lastname<input type='text' value={lastname} onChange={(e) => setlastname(e.target.value)} /><br />
                        <span>lastname</span>
                    </div>
                    <div class="inputbox">
                        Email<input type='email' value={email} onChange={(e) => setemail(e.target.value)} /><br />
                        <span>Email</span>
                    </div>
                    <div class="inputbox">
                        Password<input type='password' value={password} onChange={(e) => setpassword(e.target.value)} /><br />
                        <span>password</span><br /><br />
                        <div className='inputbox'>
                            <button onClick={AddData_Post}>Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <br /><br />

            <div class="center">
                <table>
                    {data && data.map((data, index) => {
                        return (
                            <>
                                <tr key={index}>
                                    <td>{data.username}</td>
                                    <td>{data.firt_name}</td>
                                    <td>{data.last_name}</td>
                                    <td>{data.email}</td>
                                    <td><button onClick={() => Delete(index)}>Delete</button></td>
                                    <td><button onClick={() => update(index)}>update</button></td>
                                </tr>
                            </>
                        )
                    })}
                </table>
            </div>

        </>
    );
}

export default Crud;
