import { combineReducers } from 'redux';

import todos from './todos';

const reducer = combineReducers({
  todos,
});

export default reducer;
