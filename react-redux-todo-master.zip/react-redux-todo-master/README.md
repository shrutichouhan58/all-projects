<h1 align="center">React & Redux Todo App</h1>

<p align="center">
  <img src="https://github.com/lucasbento/react-redux-todo/raw/master/content/todo.gif">
</p>

## Running

```sh
npm start
```

### Production build

```sh
npm run build # build files will be available in ./dist
```